export{Q as default}from"./vendor.Ml7xHclh.js";
