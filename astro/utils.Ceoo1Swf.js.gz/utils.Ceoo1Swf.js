import{N as r,O as o}from"./vendor.Ml7xHclh.js";function n(...n){return r(o(n))}export{n as c};
